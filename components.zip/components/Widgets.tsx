import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface WidgetsProps {
  data: any
}

export default function Widgets({ data }: WidgetsProps) {
  console.log('Widgets data:', data);
  return (
    <div className="bg-white-100 grid grid-cols-5 sm:grid-cols-6 gap-2 max-h-32">
      <Card className="bg-red-500 text-white p-1 flex flex-col justify-between">
        <CardHeader className="p-1">
          <CardTitle className="text-base" >NB Unités Mois N-1</CardTitle>
        </CardHeader>
        <CardContent className="p-1">
          <p className="text-sm font-bold">{data?.['NB UNITES MOIS N-1'] || 0}</p>
        </CardContent>
      </Card>
      <Card className="bg-purple-500 text-white p-1 flex flex-col justify-between">
        <CardHeader className="p-1">
          <CardTitle className="text-base">NB Unités Mois N-2</CardTitle>
        </CardHeader>
        <CardContent className="p-1">
          <p className="text-sm font-bold">{data?.['NB UNITES MOIS N-2'] || 0}</p>
        </CardContent>
      </Card>
      <Card className="bg-blue-500 text-white p-1 flex flex-col justify-between">
        <CardHeader className="p-1">
          <CardTitle className="text-base">NB Unités Mois N-3</CardTitle>
        </CardHeader>
        <CardContent className="p-1">
          <p className="text-sm font-bold">{data?.['NB UNITES MOIS N-3'] || 0}</p>
        </CardContent>
      </Card>
      <Card className="bg-blue-500 text-white  col-span-2 p-1 flex flex-col justify-between">
        <CardHeader className="p-1">
          <CardTitle className="text-base">NB Unités depuis le début du mois</CardTitle>
        </CardHeader>
        <CardContent className="p-1">
          <p className="text-sm font-bold">{data?.['NB UNITES DEPUIS DEBUT DU MOIS'] || 0}</p>
        </CardContent>
      </Card>
    </div>
  )
}

