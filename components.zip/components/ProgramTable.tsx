import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { useState } from 'react'
import NewRequestForm from './NewRequestForm'

interface ProgramTableProps {
  data: any[]
}

export default function ProgramTable({ data }: ProgramTableProps) {
  const [showForm, setShowForm] = useState(false);
  const [selectedProgram, setSelectedProgram] = useState('');

  console.log('ProgramTable data:', data);

  if (data.length === 0) {
    return <div>Aucune donnée disponible sur l'évolution du programme sélectionné.</div>
  }

  const handleRequestClick = (program: string) => {
    setSelectedProgram(program);
    setShowForm(true);
  };

  return (
    <>
      <div style={{ width: '80%', margin: '10px', background:'' , marginTop: '20px'}}>
        <h2 className="text-2xl font-bold mb-6 text-gray-800">Evolutions du programme</h2>
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Intitulé</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Programme</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Description</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Statut</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Gain de temps estimé</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Temps consommé</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Temps Estimé</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Tâches mensuelles</TableHead>
              <TableHead className="py-3 px-4 text-sm font-medium text-gray-600 border-b">Demande d'évolution</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, index) => (
              <TableRow 
                key={index}
                className={`${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-gray-100`}
              >
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row.Intitulé}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row.Programme}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row.Description}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row.Statut}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row['Gain de temps estimé']}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row['Temps consommé']}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row['Temps Estimé']}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-gray-800">{row['Tâches mensuelles']}</TableCell>
                <TableCell className="py-2 px-4 text-xs text-blue-600 hover:text-blue-800">
                  <button 
                    className="text-blue-600 hover:underline"
                    onClick={() => handleRequestClick(row.Programme)}
                  >
                    OK
                  </button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {showForm && (
        <NewRequestForm 
          onClose={() => setShowForm(false)} 
          initialProgram={selectedProgram}
        />
      )}
    </>
  )
}
