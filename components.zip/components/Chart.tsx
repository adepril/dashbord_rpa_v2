'use client'

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import React, { PureComponent } from 'react';

interface ChartProps {
  data: any
}

interface CustomizedAxisTickProps {
  x: number;
  y: number;
  payload: {
    value: number;
  };
}

const CustomizedAxisTick: React.FC<any> = (props) => {
    const { x, y, payload } = props;

    const date = new Date();
    const day = new Date(date.getFullYear(), date.getMonth(), payload.value);
    const formattedDate = day.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });

    return (
      <g transform={`translate(${x},${y})`}>
        <text x={0} y={0} dy={16} textAnchor="end" fill="#666" transform="rotate(-35)" fontSize={10}>
        {formattedDate}
        </text>
      </g>
    );
  }


export default function Chart({ data }: ChartProps) {
  console.log('Chart data:', data);
  if (!data) return null

  const chartData = Array.from({ length: 31 }, (_, i) => {
    const day = `JOUR${i + 1}`;
    return {
      day: i + 1,
      value: parseInt(data[day]) || 0
    };
  });

  console.log('Processed chart data:', chartData);

  if (chartData.every(item => item.value === 0)) return <div>Aucune donnée disponible pour le graphique</div>

  return (
    <ResponsiveContainer width="80%" height={400}  >
      <BarChart data={chartData}>
        <XAxis
          dataKey="day"
          stroke="#888888"
          tickLine={false}
          axisLine={false}
          tick={<CustomizedAxisTick  />} 
          tickFormatter={(tick) => tick}
          height={50}
        />
        <YAxis
          stroke="#888888"
          tickLine={false}
          axisLine={false}
          tickFormatter={(value: any) => `${value}`}
          style={{ fontSize: 10 }}
        />
        <Tooltip
          labelFormatter={(label) => {
            const date = new Date();
            const day = new Date(date.getFullYear(), date.getMonth(), label);
            return day.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
          }}
          formatter={(value, name, props) => [value]}
        />
        <Bar dataKey="value" fill="#3498db" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}

