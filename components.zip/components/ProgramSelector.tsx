import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ProgramSelectorProps {
  programs: string[]
  selectedProgram: string
  onProgramChange: (program: string) => void
}

export default function ProgramSelector({ programs, selectedProgram, onProgramChange }: ProgramSelectorProps) {
  console.log('ProgramSelector props:', { programs, selectedProgram });
  return (
    <Select value={selectedProgram} onValueChange={onProgramChange}>
      <SelectTrigger className="bg-white border border-gray-300 rounded py-2 px-4 w-[460px]">
        <SelectValue placeholder="Sélectionnez un programme" />
      </SelectTrigger>
      <SelectContent className="bg-white border border-gray-300 rounded py-2 px-4 w-[460px]">
        {programs.map((program) => (
          <SelectItem key={program} value={program}>
            {program}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}

