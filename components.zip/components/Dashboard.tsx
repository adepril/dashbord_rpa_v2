'use client'

import { useState, useEffect } from 'react'
import ProgramSelector from './ProgramSelector'
import Widgets from './Widgets'
import Chart from './Chart'
import ProgramTable from './ProgramTable'
import NewRequestButton from './NewRequestButton'
import { fetchDataReportingMoisCourant, fetchEvolutions } from '../utils/dataFetcher'
import { LetterText } from 'lucide-react'

export default function Dashboard() {
  const [programData, setProgramData] = useState<any[]>([])
  const [programList, setProgramList] = useState<string[]>([])
  const [selectedProgram, setSelectedProgram] = useState('')
  const [historiqueData, setHistoriqueData] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        console.log('Fetching data from Firebase...');
        const data = await fetchDataReportingMoisCourant();
        console.log('Data fetched:', data);
        setProgramData(data);
        
        if (data.length === 0) {
          throw new Error('Aucune donnée n\'a été récupérée de DataReportingMoisCourant');
        }
        
        const programList = [...new Set(data.map(item => `${item['AGENCE']}_${item['NOM PROGRAMME']}`))];
        console.log('Program list:', programList);
        setProgramList(programList);
        
        if (programList.length > 0) {
          console.log('Setting initial program:', programList[0]);
          setSelectedProgram(programList[0]);
        }

        // Fetch historique data
        const historique = await fetchEvolutions();
        console.log('Historique data fetched:', historique);
        
        if (historique && historique.length > 0) {
          setHistoriqueData(historique);
        } else {
          console.log('collection evolutions vide');
          setError('Aucune donnée n\'a été récupérée de la collection evolutions de Firebase');
        }

      } catch (error) {
        if (error instanceof Error) {
          console.error('Error fetching data:', error)
          setError(`Une erreur est survenue lors du chargement des données: ${error.message}`)
        } else {
          console.error('Error fetching data:', error)
          setError('Une erreur inconnue est survenue')
        }
      } finally {
        setIsLoading(false);
      }
    }
    fetchData()
  }, [])

  const handleProgramChange = (program: string) => {
    console.log('Program changed to:', program);
    setSelectedProgram(program)
  }

    const selectedProgramData = programData.find(p => `${p['AGENCE']}_${p['NOM PROGRAMME']}` === selectedProgram)
    console.log('Selected program data:', selectedProgramData);

  let filteredHistoriqueData;
  if(historiqueData.length>0) {
     filteredHistoriqueData = historiqueData.filter(item => {
      if (!selectedProgram || !item.Programme) {
        console.log('Skipping item due to missing data:', item);
        return false;
      }
      const [agence, programName] = selectedProgram.split('_');
      console.log('Filtering historique data:', item.Programme, programName, 'Agence:', agence);
      return item.Programme.toLowerCase().includes(programName.toLowerCase());
    });
  } else {
     filteredHistoriqueData = [];
  }
  console.log('Filtered historique data:', filteredHistoriqueData);

  if (isLoading) {
    return <div>Chargement des données...</div>
  }

  if (error) {
    return <div className="text-red-500">{error}</div>
  }

  return (

    <div className="space-y-4" style={{ marginTop: '20px'}}>
      <div className="flex justify-between items-center">
        <ProgramSelector  programs={programList} selectedProgram={selectedProgram} onProgramChange={handleProgramChange}/>
        <NewRequestButton />
      </div>
      
      <Chart data={selectedProgramData} />
      <Widgets data={selectedProgramData} />
      <ProgramTable data={filteredHistoriqueData} />
    </div>
  )
}

